package Unit13;

public class selectionFind {

    public static void main(String[] args) {
        System.out.println(1);
    }
}
