package csaClass;

import java.util.ArrayList;

public class QuizTest{
    private int[] name;
    public int[] vale(){
        ArrayList<Integer> ne = new ArrayList<Integer>();
        ne.add(1);
        ne.add(2);
        ne.add(3);
        ne.add(4);
        return name;

    }
}
